package com.supermarket.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.RedisTemplate;

@SpringBootTest
class DemoApplicationTests {

    @Autowired
    private RedisTemplate redisTemplate;

    @Test
    void contextLoads() {

        redisTemplate.opsForValue().set("msg", "Hello");
        redisTemplate.opsForValue().set("error", "error found");
    }

    @Test
    void testGets() {
        try{
            String msg = redisTemplate.opsForValue().get("msg").toString();
            System.out.println(msg);
        }catch (Exception e){
            System.err.println("已过期!");
        }
    }

}
