package com.supermarket.demo.service;

public interface OrderService {
}
