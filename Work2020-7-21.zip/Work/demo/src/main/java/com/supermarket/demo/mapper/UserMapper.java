package com.supermarket.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.mapper.Mapper;
import com.supermarket.demo.pojo.User;

import java.util.List;

public interface UserMapper extends BaseMapper<User> {


}
