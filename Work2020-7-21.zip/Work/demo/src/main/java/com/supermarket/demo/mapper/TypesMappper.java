package com.supermarket.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.supermarket.demo.pojo.Types;

public interface TypesMappper extends BaseMapper<Types> {
}
