package com.supermarket.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.core.annotation.Order;

public interface OrderMapper extends BaseMapper<Order> {
}
