package com.supermarket.demo.service;

import com.supermarket.demo.pojo.User;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface UserService {

    /**
     * 查找所有用户
     * @return 返回一个存在所有用户的列表
     */
    List<User> findUser();

    /**
     * 用户登录功能
     * @param user 传入用户名密码进行查询
     * @return 如果查询到用户，登录成功返回一个没有密码的用户信息，否则返回登录失败提示
     */
    User login(User user);

    /**
     * 判断是否存在当前用户，用户注册时使用
     * @return 如果存在该用户，返回true，否则返回false
     */
    boolean isExistence(String username);

    /**
     * 添加/注册一个用户
     * @param user 需要注册的用户信息
     * @return 注册成功返回true，否则返回false
     */
    @Transactional
    boolean addUser(User user);
}
