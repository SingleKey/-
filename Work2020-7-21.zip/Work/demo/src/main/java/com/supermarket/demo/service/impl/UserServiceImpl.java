package com.supermarket.demo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.supermarket.demo.mapper.UserMapper;
import com.supermarket.demo.pojo.User;
import com.supermarket.demo.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public List<User> findUser() {
        ArrayList<User>  list = (ArrayList<User>) userMapper.selectList(null);
        return list;
    }

    @Override
    public User login(User user) {

        HashMap<String, Object> stringStringHashMap = new HashMap<String, Object>();
        stringStringHashMap.put("user_name", user.getUserName());
        stringStringHashMap.put("password", user.getPassword());

        List<User> users = userMapper.selectByMap(stringStringHashMap);

        User myUser = null;
        if(users.size() > 0) {

            myUser = users.get(0);
            myUser.setPassword("");
            return myUser;
        }else{
            return null;
        }

    }

    @Override
    public boolean isExistence(String username) {
        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        User user = userMapper.selectOne(queryWrapper.like("user_name", username));

        if(user != null) {
            return true;
        }
        return false;
    }

    @Override
    public boolean addUser(User user) {
        int i = userMapper.insert(user);
        return i > 0;
    }

}
