package com.supermarket.demo.entity;

import com.supermarket.demo.pojo.User;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * falg:是否成功
 * code:返回码
 * message:返回消息
 * data：返回的数据
 */
public class Result<T> {

    private boolean flag;
    private String code;
    private String message;
    private T data;

    public Result(boolean flag, int i, String ok, User loginUser) {

    }

    public Result(boolean flag, String code, String message, T data) {
        this.flag = flag;
        this.code = code;
        this.message = message;
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public boolean getFlag() {
        return flag;
    }

}
