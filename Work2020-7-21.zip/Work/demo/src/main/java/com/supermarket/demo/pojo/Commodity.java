package com.supermarket.demo.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Commodity {

    private int id;
    private String name;
    private int number;
    private int price;
    private int typeId;
    private String photos;
    private Timestamp createTime;

}
