package com.supermarket.demo.entity;

public class Codes {

    /**
     * 接收成功，但是没有处理成功
     */
    public static int succes = 10000;

    /**
     * 没有查询到结果，或者没有修改成功
     */
    public static int fail = 40000;

}
