package com.supermarket.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.supermarket.demo.pojo.Commodity;

public interface CommodityMapper extends BaseMapper<Commodity> {
}
