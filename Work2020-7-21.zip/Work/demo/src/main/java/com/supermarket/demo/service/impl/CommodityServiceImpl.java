package com.supermarket.demo.service.impl;

import com.supermarket.demo.mapper.CommodityMapper;
import com.supermarket.demo.pojo.Commodity;
import com.supermarket.demo.service.CommodityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommodityServiceImpl implements CommodityService {

    @Autowired
    private CommodityMapper commodityMapper;

    @Override
    public List<Commodity> findAllCommdity() {
        List<Commodity> list = commodityMapper.selectList(null);
        return  list;
    }
}
