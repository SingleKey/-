package com.supermarket.demo.controller;

import com.supermarket.demo.entity.Result;
import com.supermarket.demo.pojo.Commodity;
import com.supermarket.demo.service.CommodityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "/commdity")
public class CommdityController {

    @Autowired
    private CommodityService commodityService;

    @GetMapping(value = "/findAllCommdity")
    public Result findCommdity() {
        List<Commodity> list = commodityService.findAllCommdity();
        return new Result(true, "20000", "所有商品", list);
    }
}
