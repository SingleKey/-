package com.supermarket.demo.service;

import com.supermarket.demo.pojo.Commodity;

import java.util.List;

public interface CommodityService {

    List<Commodity> findAllCommdity();
}
