package com.supermarket.demo.controller;

import com.supermarket.demo.entity.Result;
import com.supermarket.demo.pojo.User;
import com.supermarket.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "/user")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping(value = "/list")
    public Result userList() {
//        System.out.println("++++++++++++++++++++++++++++");
        List<User> user = userService.findUser();
        System.out.println(user.get(0).toString());
        return new Result(true, "2000", "OK", user);
    }

    @GetMapping(value = "/login")
    public Result login(String username, String password) {

        //判断用户名密码是否为空
        if(username == null || username.length() == 0) {
            return new Result(false, "100", "用户名不能为空", null);
        }
        if(password == null || password.length() == 0) {
            return new Result(false, "100", "密码不能为空", null);
        }
        User user = new User();
        user.setUserName(username);
        user.setPassword(password);

        //用户登录
        User loginUser = userService.login(user);

        if(loginUser != null) {
            System.err.println("请求已处理,用户" + username + "登录成功");
            return new Result(true, "20000", "登录成功", loginUser);
        }else{
            System.err.println("请求已处理,用户" + username + "登录失败");
            return new Result(false, "400", "用户名或密码错误，请重新输入", null);
        }
    }

    @GetMapping(value = "/register")
    public Result register(String user_name, String password, String mobile) {
        //注册时对用户名以及密码进行判断
        if(user_name == null || user_name.length() == 0) {
            return new Result(false, "100", "用户名不能为空", null);
        }
        if(password == null || password.length() == 0) {
            return new Result(false, "100", "密码不能为空", null);
        }
        //判断用户名是否重复
        boolean b = userService.isExistence(user_name);
        if(b) {
            return new Result(false, "900", "该用户名已被使用，请重新输入", null);
        }

        User user = new User();
        user.setUserName(user_name);
        user.setPassword(password);
        user.setMobile(mobile);
        boolean ok = userService.addUser(user);

        //注册成功，自动登录
        if(ok) {
            user.setPassword("");
            return new Result(true, "20000", "注册成功", user);
        }else{
            return new Result(false, "100", "注册失败", null);
        }
    }
}
